package com.Kani.Springboot.entity;

public class PizzaOrder {

}
