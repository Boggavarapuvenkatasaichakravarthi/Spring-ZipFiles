package com.Kani.Springboot.exceptions;


/*Controller Class for Customer Controller
Author : VenkataSaiChakravarthi
*/

public class CustomerNotFoundException extends Exception {
	public CustomerNotFoundException(String s) {
		super(s);
	}
}