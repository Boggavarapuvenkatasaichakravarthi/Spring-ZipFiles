package com.Kani.Springboot.entity;

import java.util.List;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToMany;
import javax.persistence.Table;


@Entity
@Table(name="customer")

public class Customer {
	@Id
	@GeneratedValue
	
private int customerId;
private String userName;
private String password;
private String role;
private String name;
private String address;
private String mobile;
private String email;
//private List<PizzaOrder> PizzaOrders;

//@OneToMany
//@JoinColumn(name="pizzaId")


public int getCustomerId() {
	return customerId;
}

public void setCustomerId(int customerId) {
	this.customerId = customerId;
}

public String getUserName() {
	return userName;
}

public void setUserName(String userName) {
	this.userName = userName;
}

public String getPassword() {
	return password;
}

public void setPassword(String password) {
	this.password = password;
}

public String getRole() {
	return role;
}

public void setRole(String role) {
	this.role = role;
}


public String getName() {
	return name;
}

public void setName(String name) {
	this.name = name;
}

public String getAddress() {
	return address;
}

public void setAddress(String address) {
	this.address = address;
}

public String getMobile() {
	return mobile;
}

public void setMobile(String mobile) {
	this.mobile = mobile;
}

public String getEmail() {
	return email;
}

public void setEmail(String email) {
	this.email = email;
}

/*public List<PizzaOrder> getPizzaOrders() {
	return PizzaOrders;
}

public void setPizzaOrders(List<PizzaOrder> pizzaOrders) {
	PizzaOrders = pizzaOrders;
}*/

public Customer() {
	super();
	// TODO Auto-generated constructor stub
}
/*
@Override
public String toString() {
	return "Customer [customerId=" + customerId + ", userName=" + userName + ", password=" + password + ", role=" + role
			+ ", name=" + name + ", address=" + address + ", mobile=" + mobile + ", email=" + email + ", PizzaOrders="
			+ PizzaOrders + "]";
}
*/


}
