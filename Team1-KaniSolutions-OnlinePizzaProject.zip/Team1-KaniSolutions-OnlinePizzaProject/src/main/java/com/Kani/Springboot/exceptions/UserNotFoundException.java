package com.Kani.Springboot.exceptions;

/*Controller Class for Customer Controller
Author :  VenkataSaiChakravrthi
*/

public class UserNotFoundException extends Exception{
	public UserNotFoundException(String s) {
		super(s);
	}
}
