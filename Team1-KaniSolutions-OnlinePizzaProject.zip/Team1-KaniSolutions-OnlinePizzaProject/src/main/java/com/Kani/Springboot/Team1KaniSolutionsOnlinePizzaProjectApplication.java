package com.Kani.Springboot;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Team1KaniSolutionsOnlinePizzaProjectApplication {

	public static void main(String[] args) {
		SpringApplication.run(Team1KaniSolutionsOnlinePizzaProjectApplication.class, args);
		System.out.println("SpringBoot Server Started:***..........*** ");
		
	}

}
