package com.example.SB03SpringBootMVCBeanstest;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Sb03SpringBootMvcBeansTestApplication {

	public static void main(String[] args) {
		SpringApplication.run(Sb03SpringBootMvcBeansTestApplication.class, args);
	}

}
