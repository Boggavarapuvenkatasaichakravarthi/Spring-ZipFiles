package com.example.SB03SpringBootMVCBeanstest;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Sb03SpringBootMvcBeansTestApplicationTests {

	@Test
	void contextLoads() {
	}

}
