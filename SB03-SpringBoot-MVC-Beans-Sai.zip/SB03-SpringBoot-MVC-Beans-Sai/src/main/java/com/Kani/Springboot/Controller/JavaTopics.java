package com.Kani.Springboot.Controller;

public class JavaTopics {
	private String name;
	private String destination;
	private String id;
	public JavaTopics(String name, String destination, String id) {
		super();
		this.name = name;
		this.destination = destination;
		this.id = id;
	}
	
	public String getName() {
		return name;
	}
	public String getDestination() {
		return destination;
	}
	public String getId() {
		return id;
	}
	
	
}
