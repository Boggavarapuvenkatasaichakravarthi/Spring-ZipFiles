package com.Kani.Springboot.Controller;
// http://localhost:8080/login.spring


import java.util.Arrays;
import java.util.List;

import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class MyController {
	@RequestMapping("login.spring")
 public String loginValid() {
	 return "Hello Controller";
 }
	@RequestMapping("/javatopics")
	public List getAllTopics() {
		return Arrays.asList(new JavaTopics("springBoot","springMVC","Spring"),
				new JavaTopics("JPA","Hibernate","JDBC") );
		
	}

}
