package com.Kani.Springboot;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Sb03SpringBootMvcBeansSaiApplication {

	public static void main(String[] args) {
		SpringApplication.run(Sb03SpringBootMvcBeansSaiApplication.class, args);
		System.out.println("Spring Boot-MVC ServerStart");

	}

}
