package com.Kani.Springboot;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Sb03SpringBootMvcBeansSaiApplicationTests {

	@Test
	void contextLoads() {
	}

}
