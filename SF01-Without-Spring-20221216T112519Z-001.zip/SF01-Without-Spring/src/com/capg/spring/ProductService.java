package com.capg.spring;

public interface ProductService {
	
	  public void allProducts();

}
