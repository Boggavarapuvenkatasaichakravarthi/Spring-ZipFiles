package com.ram.springboot;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Sb08SpringBootDataJpaCurdRamApplicationTests {

	@Test
	void contextLoads() {
	}

}
