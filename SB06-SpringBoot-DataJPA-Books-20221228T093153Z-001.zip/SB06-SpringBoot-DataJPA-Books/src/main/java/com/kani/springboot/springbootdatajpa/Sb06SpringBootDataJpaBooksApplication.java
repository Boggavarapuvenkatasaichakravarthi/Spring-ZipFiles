package com.kani.springboot.springbootdatajpa;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Sb06SpringBootDataJpaBooksApplication {

	public static void main(String[] args) {
		SpringApplication.run(Sb06SpringBootDataJpaBooksApplication.class, args);
		System.out.println("SpringBoot Server Start..");
	}

}
