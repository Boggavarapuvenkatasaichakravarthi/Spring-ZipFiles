package com.kani.springboot.springbootdatajpa;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Sb06SpringBootDataJpaBooksApplicationTests {

	@Test
	void contextLoads() {
	}

}
