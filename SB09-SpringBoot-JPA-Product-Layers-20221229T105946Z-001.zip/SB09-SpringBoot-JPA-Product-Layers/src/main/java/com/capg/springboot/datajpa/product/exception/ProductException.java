package com.capg.springboot.datajpa.product.exception;

 

public class ProductException extends Exception {

	public ProductException(String arg0) {
		super(arg0);
		
	}

}
