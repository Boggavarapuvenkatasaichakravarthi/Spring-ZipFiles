package com.Kani.Springboot;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Sb04SpringBootMvcBeansEmployee1ApplicationTests {

	@Test
	void contextLoads() {
	}

}
