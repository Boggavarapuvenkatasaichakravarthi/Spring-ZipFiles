package com.Kani.Springboot.Controller;

public class Employee {
private int eno;
private String ename;
private double sal;
public Employee(int eno, String ename, double sal) {
	super();
	this.eno = eno;
	this.ename = ename;
	this.sal = sal;
}

public int getEno() {
	return eno;
}
public String getEname() {
	return ename;
}
public double getSal() {
	return sal;
}


}
