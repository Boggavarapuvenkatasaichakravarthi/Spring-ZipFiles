package com.Kani.Springboot;
//http://localhost:9091/employee
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Sb04SpringBootMvcBeansEmployee1Application {

	public static void main(String[] args) {
		SpringApplication.run(Sb04SpringBootMvcBeansEmployee1Application.class, args);
		System.out.println("Spring Boot Server Started");
	}

}
