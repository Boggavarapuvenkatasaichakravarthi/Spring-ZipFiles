package com.cg.onlinepizza.OnlinePizzaOrder;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class OnlinePizzaOrderApplicationTests {

	@Test
	void contextLoads() {
	}

}
