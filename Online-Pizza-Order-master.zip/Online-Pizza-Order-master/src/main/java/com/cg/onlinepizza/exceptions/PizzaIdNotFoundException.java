package com.cg.onlinepizza.exceptions;

public class PizzaIdNotFoundException extends Exception {
	public PizzaIdNotFoundException() {
		// TODO Auto-generated constructor stub
	}

	public PizzaIdNotFoundException(String message) {
		super(message);
	}
}
