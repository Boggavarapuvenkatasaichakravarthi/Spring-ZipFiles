package com.cg.onlinepizza.exceptions;

public class InvalidCoupanOperationException extends Exception {
	public InvalidCoupanOperationException() {
		// TODO Auto-generated constructor stub
	}

	public InvalidCoupanOperationException(String message) {
	super(message);
	}
}
