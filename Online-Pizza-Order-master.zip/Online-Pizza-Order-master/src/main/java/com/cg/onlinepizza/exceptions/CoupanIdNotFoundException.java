package com.cg.onlinepizza.exceptions;

public class CoupanIdNotFoundException extends Exception {
	public CoupanIdNotFoundException() {
		// TODO Auto-generated constructor stub
	}
	public CoupanIdNotFoundException(String message) {
		super(message);
	}
}
