package com.cg.onlinepizza.exceptions;

public class InvalidMinCostException extends Exception {
	public InvalidMinCostException() {
		// TODO Auto-generated constructor stub
	}
	public InvalidMinCostException(String message) {
		super(message);
	}
}
