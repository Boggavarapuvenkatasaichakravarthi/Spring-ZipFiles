package com.cg.onlinepizza.exceptions;

public class CustomerIdNotFoundException extends Exception {
	public CustomerIdNotFoundException() {
		// TODO Auto-generated constructor stub
	}

	public CustomerIdNotFoundException(String message) {
		super(message);
	}

}
