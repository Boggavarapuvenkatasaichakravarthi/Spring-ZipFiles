package com.cg.onlinepizza.exceptions;

public class InvalidSizeException extends Exception {
	public InvalidSizeException() {
		// TODO Auto-generated constructor stub
	}

	public InvalidSizeException(String message) {
		super(message);
	}
}
