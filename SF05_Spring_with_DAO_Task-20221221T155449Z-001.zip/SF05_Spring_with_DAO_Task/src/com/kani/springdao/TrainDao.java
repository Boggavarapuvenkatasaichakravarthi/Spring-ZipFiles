package com.kani.springdao;

public interface TrainDao {
	
	public void saveTrain(Train train1);
	
	public void showTrain(int tNo);
	
	public void updateTrain(int tNo);
	
	public void deleteTrain(int tNo);
	
}
