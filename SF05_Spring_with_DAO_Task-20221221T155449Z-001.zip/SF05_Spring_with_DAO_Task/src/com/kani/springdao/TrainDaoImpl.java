package com.kani.springdao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import javax.sql.DataSource;

public class TrainDaoImpl implements TrainDao{
	
	private DataSource dataSource;
	
	public TrainDaoImpl() {}
	
	public DataSource getDataSource() {
		return dataSource;
	}
	
	public void setdataSource(DataSource dataSource) {
		this.dataSource=dataSource;
		
	}
	
	public void saveTrain(Train train1) {
		
		Connection conn=null;
		PreparedStatement pstmt = null;
		try
		{
			conn=dataSource.getConnection();
			pstmt=conn.prepareStatement("insert into train1 values(?,?,?,?,?)");
			
			pstmt.setInt(1,train1.gettNo());
			pstmt.setString(2,train1.getFirstStation());
			pstmt.setString(3,train1.getLastStation());
			pstmt.setInt(4,train1.getDistance());
			pstmt.setInt(5,train1.getTime());
			
			pstmt.execute();
			System.out.println("data inserted into Database.");
			
		}
		catch(Exception e)
		{
			System.out.println("I can handle :"+e);
		}
		finally {
			try {
				pstmt.close();
				conn.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
	}

	@Override
	public void showTrain(int tNo) {
		
		Connection conn=null;
		PreparedStatement pstmt=null;
		ResultSet rs=null;
		try {
			conn=dataSource.getConnection();
			pstmt=conn.prepareStatement("select * from train1 where Train_No="+tNo);
			rs=pstmt.executeQuery();
			while(rs.next())
			{
				System.out.println("Train No : "+rs.getInt(1));
				System.out.println("First Station : "+rs.getString(2));
				System.out.println("Last Station : "+rs.getString(3));
				System.out.println("Distance : "+rs.getInt(4)+" Kms");
				System.out.println("Time : "+rs.getInt(5)+" Hrs");
				
			}
		
		}
		catch(Exception r)
		{
			System.out.println("I can handle : "+r);
		}
		finally {
			try {
				pstmt.close();
				conn.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		
	}

	@Override
	public void updateTrain(int tNo) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void deleteTrain(int tNo) {
		Connection conn=null;
		PreparedStatement pstmt=null;
		try {
			conn=dataSource.getConnection();
			pstmt=conn.prepareStatement("delete from train1 where Train_No="+tNo);
			int del=pstmt.executeUpdate();
			System.out.println(del+" train information deleted from database.");
			
		}
		catch(Exception t)
		{
			System.out.println("I can Handle :"+t);
		}
		finally {
			try {
				pstmt.close();
				conn.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		

		
	}

}
