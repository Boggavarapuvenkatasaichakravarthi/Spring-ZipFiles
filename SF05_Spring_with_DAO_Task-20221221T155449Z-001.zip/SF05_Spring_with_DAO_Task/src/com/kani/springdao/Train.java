package com.kani.springdao;

public class Train {
	
	private int tNo;
	private String firstStation;
	private String lastStation;
	private int distance;
	private int time;
	
	public Train() {
		
	}
	public int gettNo() {
		return tNo;
	}
	public void settNo(int tNo) {
		this.tNo = tNo;
	}
	public String getFirstStation() {
		return firstStation;
	}
	public void setFirstStation(String firstStation) {
		this.firstStation = firstStation;
	}
	public String getLastStation() {
		return lastStation;
	}
	public void setLastStation(String lastStation) {
		this.lastStation = lastStation;
	}
	public int getDistance() {
		return distance;
	}
	public void setDistance(int distance) {
		this.distance = distance;
	}
	public int getTime() {
		return time;
	}
	public void setTime(int time) {
		this.time = time;
	}
	
}
