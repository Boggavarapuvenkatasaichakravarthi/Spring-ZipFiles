package com.kani.springdao;

import java.util.Scanner;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class ClientTrainDao {

	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		int sw;
		int sw1=1; 
		ApplicationContext factory=new ClassPathXmlApplicationContext("applicationContext_Dao.xml");
		
		TrainDao tDao=(TrainDao) factory.getBean("train2");
		
		
		while(sw1!=0) {
			System.out.println("\n--------Enter your choice-------\n1.To insert the information\n2.To know train details\n3.To delete the train info.\n4.Exit");
			System.out.println("\n\nEnter your choice : ");
			sw=sc.nextInt();
			switch(sw) {
			case 1:
				Train train1=new Train();
				System.out.println("Enter train number :");
				int a=sc.nextInt();
				System.out.println("Enter First Station : ");
				String b=sc.next();
				System.out.println("Enter Last Station :");
				String c=sc.next();
				System.out.println("Enter Distance :");
				int d=sc.nextInt();
				System.out.println("Enter the Time in Hrs : ");
				int e=sc.nextInt();
				train1.settNo(a);
				train1.setFirstStation(b);
				train1.setLastStation(c);
				train1.setDistance(d);
				train1.setTime(e);
				
				tDao.saveTrain(train1);
				
				System.out.println("\nTrain no: "+train1.gettNo());
				System.out.println("First Station :"+train1.getFirstStation());
				System.out.println("Last Station :"+train1.getLastStation());
				System.out.println("Distance : "+train1.getDistance()+" Kms");
				System.out.println("Time : "+train1.getTime()+"Hrs");
				
				break;
			case 2:
				System.out.println("\nTo know the train details...");
				System.out.println("Enter the train id : ");
				int id=sc.nextInt();
				
				tDao.showTrain(id);
				break;
			case 3:
				System.out.println("To delete train information");
				System.out.println("Enter the train No to delete the data :");
				int del1=sc.nextInt();
				
				tDao.deleteTrain(del1);
				break;
			case 4:
				sw1=0;
				break;
			default :
				sw1=0;
				System.out.println("Wrong option...");
				break;
			}
			
			
		}
	}
}
