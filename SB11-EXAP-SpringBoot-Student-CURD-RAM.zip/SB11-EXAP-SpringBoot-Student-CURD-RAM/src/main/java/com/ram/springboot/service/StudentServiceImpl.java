package com.ram.springboot.service;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.ram.springboot.entities.Student;

import com.ram.springboot.dao.StudentDaoI;
import com.ram.springboot.entities.Student;

@Service

public class StudentServiceImpl implements StudentServiceI{
	@Autowired
	private StudentDaoI dao;
	
	public Student CreateStudent(Student stu) {
		return dao.CreateStudent(stu);
	}
	
	public Student findStudentById(long stuId) {
		return dao.findStudentById(stuId);
	}
	public Student updateStudent(Student stu) {
		return dao.updateStudent(stu);
	}
	public List<Student> findAllStudent(){
		 return dao.findAllStudent();
	}
	public void deleteStudent(long stuId) {
		 dao.deleteStudent(stuId);
	}
}
