package com.ram.springboot.entities;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="student")
public class Student {
	@Id
	@GeneratedValue
	private long stuId;
	
	private String stuName;
	private long stuAge;

	public long getStuId() {
		return stuId;
	}
	public void setEmpId(long stuId) {
		this.stuId = stuId;
	}
	public String getStuName() {
		return stuName;
	}
	public void setStuName(String stuName) {
		this.stuName = stuName;
	}
	public long getStuAge() {
		return stuAge;
	}
	public void setStuAge(long stuAge) {
		this.stuAge = stuAge;
	}
	//constructor
	public Student() {
		super();
	}
	@Override
	public String toString() {
		return "Student [stuId=" + stuId + ", stuName=" + stuName + ", stuAge=" + stuAge + "]";
	}


}

