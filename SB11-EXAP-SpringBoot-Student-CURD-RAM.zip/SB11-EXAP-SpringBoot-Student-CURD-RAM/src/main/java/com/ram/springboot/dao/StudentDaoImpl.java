package com.ram.springboot.dao;
import java.util.List;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;
import javax.transaction.Transactional;

import org.springframework.stereotype.Repository;
import com.ram.springboot.entities.Student;

@Repository
@Transactional
public class StudentDaoImpl implements StudentDaoI {
	
	@PersistenceContext
    private EntityManager entityManager;

	@Override
	public Student CreateStudent(Student stu) {
		return entityManager.merge(stu);
	}

	@Override
	public Student findStudentById(long stuId) {
		return entityManager.find(Student.class,stuId);
	}

	@Override
	public Student updateStudent(Student student) {
		//Student stu=entityManager.find(Student.class,student.getstuId());
		
		Student stu=findStudentById(student.getStuId());
		stu.setStuName(student.getStuName());
		stu.setStuAge(student.getStuAge());
		stu=entityManager.merge(stu);
		return stu;
	}
	
	@Override
	public List<Student> findAllStudent() {
		                                // Select * from Student
		Query q = entityManager.createQuery("select s from Student s");
	    List<Student> list=q.getResultList();
		return list;
	}
	@Override
	public void deleteStudent(long stuId) {
		Student stu=entityManager.find(Student.class, stuId);
		entityManager.remove(stu);
	}

}


	
