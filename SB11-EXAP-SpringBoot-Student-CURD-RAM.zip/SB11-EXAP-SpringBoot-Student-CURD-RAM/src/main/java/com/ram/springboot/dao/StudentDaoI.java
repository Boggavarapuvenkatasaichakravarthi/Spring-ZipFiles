package com.ram.springboot.dao;
import java.util.List;

import com.ram.springboot.entities.Student;

public interface StudentDaoI {
	
	Student CreateStudent(Student stu);
	Student findStudentById(long stuId);
	Student updateStudent(Student stu); 
	List<Student> findAllStudent();
	void deleteStudent(long stuId);
}
