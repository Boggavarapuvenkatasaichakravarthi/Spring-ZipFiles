package com.cgi.myspring;

public interface ProductService {
	
	public void allProducts();
}
